import React from "react";
import { cn } from "@/lib/utils";
import { Button } from "../ui/button";

interface Props {
  className?: string;
}
const orderProducts = [
  {
    id: 1,
    name: "Porcelain Dinner Plate (27cm)",
    price: 59,
  },
  {
    id: 2,
    name: "Ophelia Matte Natural  Vase",
    price: 168,
  },
  {
    id: 3,
    name: "Luana Bowl",
    price: 49,
  },
];
export const CheckoutTotal: React.FC<Props> = (props) => {
  const { className } = props;
  return (
    <div className={cn("max-w-104 w-full", className)}>
      <table className="w-full mb-12">
        <thead>
          <tr className="font-semibold text-[20px] leading-[140%] text-primary">
            <th className="text-start pb-5">Product</th>
            <th className="text-end pb-5">Subtotal</th>
          </tr>
          <tr className="border-t">
            <td className="pb-10" colSpan={2}></td>
          </tr>
        </thead>
        <tbody className="">
          {orderProducts.map((el) => (
            <tr key={el.id} className="text-[14px] leading-[157%] text-primary">
              <td>{el.name}</td>
              <td className="text-end">{el.price}</td>
            </tr>
          ))}
          <tr className="text-[14px] font-semibold leading-[157%] text-primary">
            <td className="pt-10">Subtotal</td>
            <td className="text-end pt-10">$475.00</td>
          </tr>
          <tr className="text-[14px] font-semibold leading-[157%] text-primary">
            <td className="pb-10">Shipping</td>
            <td className="text-end pb-10">$15.00</td>
          </tr>
        </tbody>
        <tfoot className=" border-t">
          <tr className="font-semibold text-[20px] leading-[140%] text-primary">
            <td className="pt-5">Total</td>
            <td className="text-end pt-5">$490.00</td>
          </tr>
        </tfoot>
      </table>
      <div className="grid p-7.5 gap-5 text-white bg-primary">
        <h3 className="ont-semibold text-[20px] leading-[140%]">Payment</h3>
        <div className="flex gap-2 justify-center py-5 border-b border-white">
          <svg
            width="38"
            height="24"
            viewBox="0 0 38 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g clipPath="url(#clip0_52_2831)">
              <path
                opacity="0.07"
                d="M35 0H3C1.3 0 0 1.3 0 3V21C0 22.7 1.4 24 3 24H35C36.7 24 38 22.7 38 21V3C38 1.3 36.6 0 35 0Z"
                fill="black"
              />
              <path
                d="M35 1C36.1 1 37 1.9 37 3V21C37 22.1 36.1 23 35 23H3C1.9 23 1 22.1 1 21V3C1 1.9 1.9 1 3 1H35Z"
                fill="white"
              />
              <path
                d="M28.3 10.1H28C27.6 11.1 27.3 11.6 27 13.1H28.9C28.6 11.6 28.6 10.9 28.3 10.1ZM31.2 16H29.5C29.4 16 29.4 16 29.3 15.9L29.1 15L29 14.8H26.6C26.5 14.8 26.4 14.8 26.4 15L26.1 15.9C26.1 16 26 16 26 16H23.9L24.1 15.5L27 8.7C27 8.2 27.3 8 27.8 8H29.3C29.4 8 29.5 8 29.5 8.2L30.9 14.7C31 15.1 31.1 15.4 31.1 15.8C31.2 15.9 31.2 15.9 31.2 16ZM17.8 15.7L18.2 13.9C18.3 13.9 18.4 14 18.4 14C19.1 14.3 19.8 14.5 20.5 14.4C20.7 14.4 21 14.3 21.2 14.2C21.7 14 21.7 13.5 21.3 13.1C21.1 12.9 20.8 12.8 20.5 12.6C20.1 12.4 19.7 12.2 19.4 11.9C18.2 10.9 18.6 9.5 19.3 8.8C19.9 8.4 20.2 8 21 8C22.2 8 23.5 8 24.1 8.2H24.2C24.1 8.8 24 9.3 23.8 9.9C23.3 9.7 22.8 9.5 22.3 9.5C22 9.5 21.7 9.5 21.4 9.6C21.2 9.6 21.1 9.7 21 9.8C20.8 10 20.8 10.3 21 10.5L21.5 10.9C21.9 11.1 22.3 11.3 22.6 11.5C23.1 11.8 23.6 12.3 23.7 12.9C23.9 13.8 23.6 14.6 22.8 15.2C22.3 15.6 22.1 15.8 21.4 15.8C20 15.8 18.9 15.9 18 15.6C17.9 15.8 17.9 15.8 17.8 15.7ZM14.3 16C14.4 15.3 14.4 15.3 14.5 15C15 12.8 15.5 10.5 15.9 8.3C16 8.1 16 8 16.2 8H18C17.8 9.2 17.6 10.1 17.3 11.2C17 12.7 16.7 14.2 16.3 15.7C16.3 15.9 16.2 15.9 16 15.9M5 8.2C5 8.1 5.2 8 5.3 8H8.7C9.2 8 9.6 8.3 9.7 8.8L10.6 13.2C10.6 13.3 10.6 13.3 10.7 13.4C10.7 13.3 10.8 13.3 10.8 13.3L12.9 8.2C12.8 8.1 12.9 8 13 8H15.1C15.1 8.1 15.1 8.1 15 8.2L11.9 15.5C11.8 15.7 11.8 15.8 11.7 15.9C11.6 16 11.4 15.9 11.2 15.9H9.7C9.6 15.9 9.5 15.9 9.5 15.7L7.9 9.5C7.7 9.3 7.4 9 7 8.9C6.4 8.6 5.3 8.4 5.1 8.4L5 8.2Z"
                fill="#142688"
              />
            </g>
            <defs>
              <clipPath id="clip0_52_2831">
                <rect width="38" height="24" fill="white" />
              </clipPath>
            </defs>
          </svg>
          <svg
            width="38"
            height="24"
            viewBox="0 0 38 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g clipPath="url(#clip0_52_2835)">
              <path
                opacity="0.07"
                d="M35 0H3C1.3 0 0 1.3 0 3V21C0 22.7 1.4 24 3 24H35C36.7 24 38 22.7 38 21V3C38 1.3 36.6 0 35 0Z"
                fill="black"
              />
              <path
                d="M35 1C36.1 1 37 1.9 37 3V21C37 22.1 36.1 23 35 23H3C1.9 23 1 22.1 1 21V3C1 1.9 1.9 1 3 1H35Z"
                fill="white"
              />
              <path
                d="M15 19C18.866 19 22 15.866 22 12C22 8.13401 18.866 5 15 5C11.134 5 8 8.13401 8 12C8 15.866 11.134 19 15 19Z"
                fill="#EB001B"
              />
              <path
                d="M23 19C26.866 19 30 15.866 30 12C30 8.13401 26.866 5 23 5C19.134 5 16 8.13401 16 12C16 15.866 19.134 19 23 19Z"
                fill="#F79E1B"
              />
              <path
                d="M22 12C22 9.60005 20.8 7.50005 19 6.30005C17.2 7.60005 16 9.70005 16 12C16 14.3 17.2 16.5 19 17.7C20.8 16.5 22 14.4 22 12Z"
                fill="#FF5F00"
              />
            </g>
            <defs>
              <clipPath id="clip0_52_2835">
                <rect width="38" height="24" fill="white" />
              </clipPath>
            </defs>
          </svg>
        </div>
        <Button className="bg-transparent text-white border-white">
          PLACE ORDER
        </Button>
      </div>
    </div>
  );
};
